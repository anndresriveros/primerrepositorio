//5) Pida al usuario que ingrese una frase. Luego realice lo siguiente:
//a. Creando un arreglo cuya dimensión sea equivalente a la cantidad de palabras de
//la frase, guarda cada palabra en un casillero del arreglo.
//b. Muestre la palabra central del arreglo, si la tiene.
//c. Observando cada palabra, determine el elemento central de cada palabra
//guardada si es que lo tiene. Si no tiene elemento central, lo indica con un
//mensaje.

package practico4;
import java.util.*;
public class ejercicio5 {
public static void main(String[] args) {
        int palCent=0;
        int elementoCent=0;
        int longi=0;
        Scanner entrada=new Scanner(System.in);
        System.out.println("Ingrese una frase");
        String frase = entrada.nextLine();
        StringTokenizer cantPal = new StringTokenizer(frase);
        int tamaño=(cantPal.countTokens());
        String[] array = frase.split(" ");
        
        for(int i=0;i<array.length;i++){
           System.out.println(array[i]+" "+i);
       
        } 
        System.out.println("Número de palabras:"+cantPal.countTokens());
        System.out.println("tamaño "+tamaño);
        if(tamaño%2!=0){
            palCent=(tamaño/2);
            System.out.println("la palabra central es "+array[palCent]);
            
        }else{
            System.out.println("no posee palabra central");
        }
      
        for (int i=0;i<array.length;i++){
            if ((array[i].length())%2!=0){
                longi=(array[i].length()/2);
                System.out.println("la palabra "+array[i]+" posee elemento central: "+array[longi].charAt(longi));
                
            }else{
                System.out.println("La palabra "+ array[i]+ " No posee elemento central ");
            }
        }     
    }
}



//   
//       Scanner sc = new Scanner(System.in);
//       String frase;
//       System.out.print("Introduce una frase: ");
//       frase = sc.nextLine();
//       StringTokenizer st = new StringTokenizer(frase);
//       System.out.println("Número de palabras: " + st.countTokens());                                             
    
 
    
    

