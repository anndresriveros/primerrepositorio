//6) Hacer un algoritmo que llene una matriz de n * m ó de n * n. Sumar las columnas y
//guardar cada resultado en un vector o arreglo de una dimensión. Luego mostrar el índice de la
//columna que tuvo la máxima suma y el resultado de esa suma
package practico4;
import java.util.*;

public class ejercicio6mejorado {

    
    public static void main(String[] args) {
        Scanner dim =new Scanner(System.in);
        System.out.println("Ingrese la dimensión de la matriz(nxn): ");
        int dimension=dim.nextInt();
        int array[]=new int[dimension];
        int matriz2[]=new int[dimension];
        int matriz[][]=new int [dimension][dimension];
        int maxsuma=0;
        for(int f=0;f<matriz.length;f++){
                for(int c=0;c<matriz[0].length;c++){
                    matriz[f][c]=(int)(Math.random()*10);
                }    
        }    
        for(int f=0;f<matriz.length;f++){
                for(int c=0;c<matriz[0].length;c++)
                    System.out.print(matriz[f][c]+"-");
                    System.out.println(""); 
        }
        for (int c = 0; c < matriz[0].length; c++) {
        int suma = 0;
            for (int f = 0; f < matriz.length; f++) {
               for(int i=0;i<array.length;i++)
               suma += matriz[f][c];
               array[c]=suma;    
            }
       
    }
    System.out.println("");    
    System.out.println("vector resultante de las sumas: ");
    for(int i=0;i<array.length;i++){
        System.out.println(array[i]);
    }
    for(int i=0;i<array.length;i++){
        if(array[i]>=maxsuma){
            maxsuma=array[i];
        }
    }
   System.out.println("El mayor de los resultados de las sumas es: "+maxsuma);     
  }
}
