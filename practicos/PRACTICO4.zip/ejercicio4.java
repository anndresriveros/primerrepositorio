//4) Se tienen almacenados en la memoria dos vectores M y N de 20 elementos cada uno.
//Hacer un algoritmo que escriba la palabra “Iguales” si ambos vectores son iguales y
//“Diferentes” si no lo son. Aclaración: Serán iguales cuando en la misma posición de ambos
//vectores se tenga el mismo valor para todos los elementos.
package practico4;

import java.util.Scanner;


public class ejercicio4 {

   
    public static void main(String[] args) {
Scanner entrada=new Scanner(System.in);

int igualdad=0;

int M[]= new int[20];

int N[]= new int[20];
 
System.out.println("primer arreglo");
for (int i=0;i<M.length;i++){
    int ent=entrada.nextInt();
    M[i]=ent;
}
System.out.println("segundo arreglo");
for (int j=0;j<N.length;j++){
    int ent=entrada.nextInt();
    N[j]=ent;
}

for (int i=0;i<20;i++){
       if (M[0+i]== N[0+i]){
       igualdad++;
           if (igualdad==3){
              System.out.println("Los arreglos son iguales");
        }
        
    }else{
        System.out.println("Los arreglos NO son iguales");
    }  
}
    }
}
