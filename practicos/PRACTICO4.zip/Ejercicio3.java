//3) Almacenar 15 números en un vector, almacenarlos en otro vector en orden inverso al
//vector original y mostrar en pantalla, ambos. 
package practico4;


public class Ejercicio3 {

  
    public static void main(String[] args) {
      
        int matriz[]=new int[15];
        int inverso[]=new int[15];
        
        for (int i=0;i<15;i++){
            matriz[i]=(int)(Math.random()*10);
            System.out.print("["+matriz[i]+"]");
        }
        System.out.println("");
        for (int i=0;i<15;i++){
            inverso[i]=matriz[14-i];
            System.out.print("["+inverso[i]+"]");
        }
             
    }
    
}
