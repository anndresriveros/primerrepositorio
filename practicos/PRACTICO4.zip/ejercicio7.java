//7) Hacer un algoritmo que llene una matriz de 5 * 5 y que almacene la diagonal principal
//en un vector. Imprimir el vector resultante. 
package practico4;


public class ejercicio7 {

 
    public static void main(String[] args) {
        
        
        int matriz[][]=new int[5][5];
        int matriz2[]=new int[5];
        
        for (int f=0;f<matriz.length;f++){
            for(int c=0;c<matriz[0].length;c++){
                matriz[f][c]=(int)(Math.random()*10);
                if (f==c){
                  matriz2[f]=matriz[f][c];
                                          
                }
            }
        }
        for(int f=0;f<matriz.length;f++){
                for(int c=0;c<matriz[0].length;c++)
                    System.out.print(matriz[f][c]+"-");
                    System.out.println("");  
        }
        for(int i=0;i<matriz2.length;i++){
        System.out.println(""+matriz2[i]);    
        }
        
    }
    
}
