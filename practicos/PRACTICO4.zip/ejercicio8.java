//
package practico4;


public class ejercicio8 {

   
    public static void main(String[] args) {
        
        int g=4;
        int matriz[][]=new int[5][5];
        int vector[]=new int[5];
        
        for (int f=0;f<matriz.length;f++){
            for(int c=0;c<matriz[0].length;c++){
                matriz[f][c]=(int)(Math.random()*10);

                }
            }
        
        for(int f=0;f<matriz.length;f++){
                for(int c=0;c<matriz[0].length;c++)
                    System.out.print(matriz[f][c]+"-");
                    System.out.println("");  
        }
       for (int i=0;i<matriz.length;i++){
           vector[i]=matriz[i][g];
           g--;
       }
        System.out.println("");
        for(int i=0;i<vector.length;i++){
            System.out.print(vector[i]+" - ");
        }
    
    }
    }
