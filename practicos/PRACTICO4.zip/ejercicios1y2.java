//1) Calcular el promedio de 10 valores almacenados en un vector. 
//2) Determinar con el vector anterior, cuántos son mayores que el promedio; mostrar el
//promedio, el número de datos mayores que el promedio y una lista de valores mayores que el
//promedio.
package practico4;
import java.util.*;
public class Practico4 {
    public static void main(String[] args) {
       
        Scanner entrada=new Scanner(System.in);
        
        double mayor_Que_promedio=0; 
        
        double total=0;
        
        double promedio;
        
        double matriz[]=new double[4];
        
        System.out.println("Ingrese 10 notas para calcular su promedio");
        
        for (int i=0;i<4;i++){
            matriz[i]=entrada.nextDouble();
            total=(total+matriz[i]);
            
        }
      
            
        
        promedio=(total/4);
        System.out.println("El promedio es de "+promedio);
        
        for (int i=0;i<4;i++){
            if (matriz[i]>promedio){
                System.out.println(matriz[i]+" es mayor que el promedio");
                mayor_Que_promedio++;
            }
        }
    System.out.println("Valores ingresados mayores que el promedio:"+mayor_Que_promedio);
}
}